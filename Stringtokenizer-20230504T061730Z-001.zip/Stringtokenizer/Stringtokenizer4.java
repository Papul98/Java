import java.util.StringTokenizer;  
  
public class Stringtokenizer4  
{ 
  public static void main(String args[])  
   {    
     
     StringTokenizer st = new StringTokenizer("Good Evening welcome java class"," ");    
     System.out.println("Total Tokens: "+st.countTokens());    
   }    
}  