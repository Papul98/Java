
import java.util.*;
  public class UsingArrays
   {
     private int intValues[] = { 1, 2, 3, 4, 5, 6 };
     private double doubleValues[] = { 8.4, 9.3, 1.2, 7.9, 3.4 };
     private int filledInt[], intValuesCopy[];

     // initialize arrays
     public UsingArrays()  // constructor
      {
 	     filledInt = new int[ 10 ];
         intValuesCopy = new int[intValues.length];
         Arrays.fill( filledInt, 7 ); // fill with 7s
         Arrays.sort( doubleValues ); // sort doubleValues
         System.arraycopy( intValues, 0, intValuesCopy, 0, intValues.length );
      }

     // output values in each array
     public void printArrays()
      {
        System.out.print("doubleValues: ");
        for(int i = 0; i < doubleValues.length; i++)
         System.out.print( doubleValues[ i ] + " " );

        System.out.print( "\nintValues: " );

        for(int i = 0; i < intValues.length; i++)
         System.out.print( intValues[ i ] + " " );

       System.out.print( "\nfilledInt: " );

        for(int i = 0; i < filledInt.length; i++)
          System.out.print( filledInt[ i ] + " " );

         System.out.print( "\nintValuesCopy: " );
        for (int i = 0; i < intValuesCopy.length; i++)
         System.out.print( intValuesCopy[ i ] + " " );

        System.out.println(); 
       }

 // find value in array intValues
     public int searchForInt( int value )
      {
          return Arrays.binarySearch( intValues, value );
      }
 
  // compare array contents
     public void printEquality()
      {
        boolean b = Arrays.equals( intValues, intValuesCopy );
        System.out.println( "intValues " + ( b ? "==" : "!=" )+ " intValuesCopy" );
        b = Arrays.equals( intValues, filledInt );
        System.out.println( "intValues " + ( b ? "==" : "!=" )+ " filledInt" );
      }

     // execute application
    public static void main( String args[] )
     {
       UsingArrays usingArrays = new UsingArrays();

       usingArrays.printArrays();
       usingArrays.printEquality();

       int location = usingArrays.searchForInt( 5 );
       System.out.println( ( location >= 0 ?"Found 5 at element " + location : "5 not found" ) + " in intValues" );

      location = usingArrays.searchForInt(8763);
      System.out.println( ( location >= 0 ?"Found 8763 at element " + location : "8763 not found" ) + " in intValues" );
     }

  } // end class UsingArrays