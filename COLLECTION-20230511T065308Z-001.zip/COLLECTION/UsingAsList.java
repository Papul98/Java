import java.util.*;

  public class UsingAsList
   {
      private String values[] = { "red", "white", "blue" };
      private List list;
      // initialize List and set value at location 1
      public UsingAsList()
       {
         list = Arrays.asList( values ); // get List
         list.set( 1, "green" ); // change a value
         values[2]="yellow";
       }

      // output List and array
      public void printElements()
       {
          System.out.print( "List elements : " );

          for(int i = 0; i < list.size(); i++)
            System.out.print( list.get( i ) + " " );
            System.out.print( "\nArray elements: " );
          for(int i = 0; i < values.length; i++)
            System.out.print( values[ i ] + " " );
          System.out.println();
       }

     // execute application
     public static void main( String args[] )
      {
         new UsingAsList().printElements();
      }

   } // end class UsingAsLis