
 import java.util.*;

 public class SORT1
  {
   private static String suits[] ={ "Hearts", "Diamonds", "Clubs", "Spades" };

      // display array elements
     public void show()
      {
        // create ArrayList
         ArrayList list = new ArrayList(Arrays.asList(suits));

        // output list
         System.out.println("Unsorted array elements:\n" +list);

        // sort ArrayList
        Collections.sort(list);

        // output list
        System.out.println("Sorted array elements:\n" + list );
       }

       // execute application
    public static void main( String args[] )
     {
        /*
        SORT1 obj=new SORT1();
        obj.show();
        */
        new SORT1().show();
     }

  } // end class Sort1
