 import java.util.*;

  public class Algorithms1 
   {
     private String letters[]={"P","C","M"},lettersCopy[];
     private List list, copyList;
     // create a List and manipulate it with algorithms from
     // class Collections
     public Algorithms1()
      {
        list = Arrays.asList( letters ); // get List
        lettersCopy = new String[ 3 ];
        copyList = Arrays.asList( lettersCopy );

        System.out.println( "Printing initial statistics: " );
        printStatistics( list );

        Collections.reverse( list ); // reverse order
        System.out.println("\nPrinting statistics after "+"calling reverse: ");
        printStatistics( list );

        Collections.copy( copyList, list ); // copy List
        System.out.println("\nPrinting statistics after "+"copying: ");
        printStatistics(copyList);

        System.out.println( "\nPrinting statistics after " +"calling fill: ");
        Collections.fill( list, "R" );
        printStatistics( list );
      }

     // output List information
     private void printStatistics( List listRef )
      {
       System.out.print( "The list is: " );
       for(int k = 0; k < listRef.size(); k++)
         System.out.print( listRef.get( k ) + " " );
       System.out.print( "\nMax: " + Collections.max( listRef ) );
       System.out.println(" Min: " + Collections.min( listRef ));
      }
   // execute application
    public static void main( String args[] )
     {
        new Algorithms1();
     }
 
   } // end class Algorithms1