import java.util.*;

 public class ListTest
  {
    private String colors[] = { "black", "yellow", "green", "blue", "violet", "silver" };
    private String colors2[] = { "gold", "white", "brown", "blue", "gray", "silver" };

 // set up and manipulate LinkedList objects
 
    public ListTest()
     {
       LinkedList link = new LinkedList();
       LinkedList link2 = new LinkedList();

       // add elements to each list
       for(int i = 0; i < colors.length; i++) 
        {
          link.add( colors[ i ] );
          link2.add( colors2[ i ] );
        }

          link.addAll( link2 ); // concatenate lists
          link2 = null; // release resources

          printList( link );

          uppercaseStrings( link );

         printList( link );

          System.out.print( "\nDeleting elements 4 to 6..." );
          removeItems( link, 4, 7 );

          printList( link );
     }

       // output List contents
     public void printList( List list )
      {
          System.out.println( "\nlist: " );
 
        for(int i = 0; i < list.size(); i++)
          System.out.print( list.get( i ) + " " );

          System.out.println();
      }

     public void uppercaseStrings( List list )
      // locate String objects and convert to uppercase
       {
         ListIterator iterator = list.listIterator();
         while(iterator.hasNext())
          {
           Object object = iterator.next(); // get item

           if (object instanceof String) // check for String
             iterator.set(((String)object).toUpperCase());
          }
        }

   // obtain sublist and use clear method to delete sublist items
   public void removeItems( List list, int start, int end )
    {
        list.subList( start, end ).clear(); // remove items
    }

      // execute application
   public static void main( String args[] )
    {
      new ListTest();
    }

  } // end class ListTest