
 import java.awt.Color;
 import java.util.*;

 public class CollectionTest
  {
   private String colors[] = { "red", "white", "blue" };

 // create ArrayList, add objects to it and manipulate it
     
    public CollectionTest()
      {
       ArrayList list = new ArrayList();

       // add objects to list
       list.add( Color.magenta ); // add a color object
       for ( int i = 0; i < colors.length; i++ )
         list.add(colors[ i ]);
       list.add(Color.cyan); // add a color object
       
       // output list contents
       
       System.out.println( "\nArrayList: " );
       for(int i = 0; i < list.size(); i++)
         System.out.print( list.get( i ) + " " );
       // remove all String objects
        removeStrings( list );
       // output list contents
     //  System.out.println( "\n\nArrayList after calling"+" removeStrings: ");
      for (int i = 0; i < list.size(); i++)
         System.out.print( list.get( i ) + " " );
      }

   // remove String objects from Collection
    public void removeStrings( Collection collection )
     {
       // get iterator
       Iterator iterator = collection.iterator();
       // loop while collection has items
       while(iterator.hasNext())
        if(iterator.next() instanceof String)
         iterator.remove(); // remove String object
     }

  // execute application
   public static void main( String args[] )
    {
      new CollectionTest();
    }
  } // end class CollectionTest