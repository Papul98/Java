import java.util.*;

  public class UsingToArray
    {

     // create LinkedList, add elements and convert to array
     public UsingToArray()
      {
        LinkedList links;
        String colors[] = { "black", "blue", "yellow" };

        links = new LinkedList( Arrays.asList( colors ) );

        links.addLast("red"); // add as last item
        links.add("pink"); // add to the end
        links.add(3,"green"); // add at 3rd index
        links.addFirst("cyan"); // add as first item
        // get LinkedList elements as an array
        
        // "cyan","black", "blue", "yellow",,"green","red","pink",
        
        colors = ( String [] ) links.toArray(new String[ links.size() ]);

        System.out.println("colors: ");

        for(int i = 0; i < colors.length; i++)
          System.out.println( colors[ i ] );
      }

      // execute application
     public static void main( String args[] )
      {
         new UsingToArray();
      }

    } // end class UsingToArray