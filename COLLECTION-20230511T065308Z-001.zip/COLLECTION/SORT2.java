 import java.util.*;

  public class SORT2 
   {
     private static String suits[]={"Hearts","Diamonds","Clubs","Spades"};
      // output List elements
      public void show()
      {
        // create List
        List list = Arrays.asList( suits );
        
        // output List elements
        System.out.println("Unsorted array elements:\n"+list);
        
        // sort in descending order using a comparator
        Collections.sort(list, Collections.reverseOrder());
        // output List elements
        System.out.println("Sorted list elements:\n"+list);
      }
     // execute application
     public static void main( String args[] )
      {
        new SORT2().show();
      }
   } // end class Sort2