
public class PureFunction {

	public static void main(String[] args) {
	      int result = sum(12,3);
	      System.out.println(result);
	  
	      result = sum(12,3);
	      System.out.println(result);
	   }
	   static int sum(int a, int b){
	      return a + b;
	   }

}

/*
A function is considered as Pure Function if it fulfils the following two conditions -
It always returns the same result for the given inputs and its results purely depends upon the inputs passed.
It has no side effects means it is not modifying any state of the caller entity.
*/