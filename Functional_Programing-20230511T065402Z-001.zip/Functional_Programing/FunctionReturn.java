

import java.util.function.*;


public class FunctionReturn {

	public static void main(String[] args) {
		
		  Function<Integer, Integer> obj1 = adder(1);
	      Function<Integer, Integer> obj2 = adder(2);
	      Function<Integer, Integer> obj3 = adder(3);

	      //result = 4 + 1 = 5
	      Integer res1 = obj1.apply(4);
	      System.out.println(res1);

	      //result = 4 + 2 = 6
	      Integer res2 = obj2.apply(4);
	      System.out.println(res2);

	      //result = 4 + 3 = 7
	      Integer res3 = obj3.apply(4);
	      System.out.println(res3);
	   }

	   //adder - High Order Function
	   //returns a function as lambda expression
	   static Function<Integer, Integer> adder(Integer x){
	      return y -> y + x;
	   }

	}


/*
 
 As a High Order function can return a function but how to implement using Java 8. Java 8 has provided Function interface which 
 can accept a lambda expression. A high order function can return a lamdba expression and thus this high order function 
 can be used to create any number of functions.
 
 */
 


