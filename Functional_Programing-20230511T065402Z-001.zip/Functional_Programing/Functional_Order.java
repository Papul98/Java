import java.util.*;

public class Functional_Order {

	public static void main(String[] args) {
		
		
		  List<Integer> num = Arrays.asList(34, 40, 60, 17, 39);

	      //Passing a function as lambda expression
	      Collections.sort(num, (a,b) ->{ return a.compareTo(b); });

	      System.out.println(num);
	      Comparator<Integer> comparator = (a,b) ->{ return a.compareTo(b); };
	      Comparator<Integer> rev = comparator.reversed();
	      
	      //Passing a function
	      Collections.sort(num, rev);
	      System.out.println(num);

	}

}

/*
 
 A function is considered as a High Order function if it fulfils any one of the following conditions.

a) It takes one or more parameters as functions.

b) It returns a function after its execution.

Java 8 Collections.sort() method is an ideal example of a high order function.

 */
