
public class ImpureFunction {

	   private static double valueUsed = 0.0; 
	   public static void main(String[] args) {
	      double result = randomSum(2.0,3.0);
	      System.out.println(result);
	      result = randomSum(2.0,3.0);
	      System.out.println(result);
	   }
	   
	   static double randomSum(double a, double b){
	      valueUsed = Math.random();       
	      return valueUsed + a + b;
	   }
}
/*
      Here randomSum() is an impure function as it return different results when passed 2 and 3 as parameters at different
      times and modifies state of instance variable as well.
*/