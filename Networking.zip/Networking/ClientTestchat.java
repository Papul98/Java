import java.io.*;
import java.net.*;
public class ClientTestchat
{
	public static void main(String args[])
	{
		String welcome;
		String response;
		Client client;
		String s1,s2;
		BufferedReader reader;
		PrintWriter writer;
		client=new Client("localhost",8001);
		try
		
		   {
		     reader=new BufferedReader(new InputStreamReader(client.in));
		     writer=new PrintWriter(new OutputStreamWriter(client.out));
		     welcome=reader.readLine();
		     System.out.println("Server says:'"+welcome+"'");
		while(true)
		
		    {
		      DataInputStream d=new DataInputStream(System.in);
		      System.out.print("Enter string::");
		      s1=d.readLine();
		      writer.println(s1);
		      writer.flush();
		      response=reader.readLine();
		      System.out.println("Server response::"+response+"");
		    }
		   }
		catch(IOException e)
		{
			System.out.println("IOException in client in client:in.readLine()");
			System.out.println(e);
		}
		try
		{
			Thread.sleep(2000);
		}
		catch(Exception ignored)
		{
			
		}
	}
}

class Client
{
	public InputStream in;
	public OutputStream out;
	private Socket client;
	public Client(String host,int port)
	{
		try
		{
			client=new Socket(host,port);
			System.out.println("ClientSocket:"+client);
			out=client.getOutputStream();
			in=client.getInputStream();
		}
		catch(IOException e)
		{
			System.out.println("IOExc:"+e);
		}
	}
} 