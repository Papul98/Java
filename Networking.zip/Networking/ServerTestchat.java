import java.util.*;
import java.io.*;
import java.net.*;
public class ServerTestchat
{
	final static int SERVER_PORT=8001;
	public static void main(String args[])
	{
		String s1;
		Server server;
		String clientRequest;
		BufferedReader reader;
		PrintWriter writer;
		server=new Server(SERVER_PORT);
		reader=new BufferedReader(new InputStreamReader(server.in));
		writer=new PrintWriter(new OutputStreamWriter(server.out));
		writer.println("Java Test Server vo.02::"+new Date());
		writer.flush();
		while(true)
		{
			try
			{
				clientRequest=reader.readLine();
				System.out.println("Client says::"+clientRequest);
				if(clientRequest.startsWith("HELP"))
				{
			    writer.println("Vocabulary:HELP QUIT");
				writer.flush();
				}
				else
				{
				if(clientRequest.startsWith("QUIT"))
					{
						System.exit(10);
					}	
				else
				   {
					DataInputStream d=new DataInputStream(System.in);
				    System.out.print("Enter the String::");
				    s1=d.readLine();
				    writer.println(s1);
		            writer.flush();
				   }
               }
			}
			catch(IOException e)
			{
			System.out.println("IOEx in Server"+e);
			}
		}
	}
}

class Server
{
	private ServerSocket server;
	private Socket socket;
	public InputStream in;
	public OutputStream out;
	public Server(int port)
	{
	  try
	  {
	  	server=new ServerSocket(port);
	  	System.out.println("ServerSocket before accept:"+server);
	  	System.out.println("Java Test Server vo.02,on-line:");
	  	socket=server.accept();
	  	System.out.println("ServerSocket after accept:"+server);
	  	in=socket.getInputStream();
	  	out=socket.getOutputStream();
	  }
	  catch(IOException e)	
	  {
	  	System.out.println("Server Constructor IOEx:"+e);
	  }
	}
}