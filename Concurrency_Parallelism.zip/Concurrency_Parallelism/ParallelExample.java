import java.util.*;


public class ParallelExample {

	public static void main(String[] args) {
		  List<String> stringList = List.of("Ananya", "Jocelyn", "Julia", "Laila", "Riddhima", "Trisha");

	        System.out.println("With || ism");
	        stringList.parallelStream().map(String::toUpperCase).forEach(s ->
	        {
	            System.out.println(s + " " + Thread.currentThread().getName());
	        });

	        System.out.println("Without || ism");
	        stringList.stream().map(String::toUpperCase).forEach(s ->
	        {
	            System.out.println(s + " " + Thread.currentThread().getName());
	        });


	}

}


/*

With Parallelism we can break a program into smaller tasks 
and can execute them at exact same time in parallel by leveraging the multiple CPU cores.
*/