/**
 * @(#)file.java
 */

import java.io.*;

public class file11 
{
    public static void main(String[] args) 
    {
        File file=new File(args[0]);
        
		if(!file.exists())
		{
			System.out.print(args[0]+" does not exist");
			return;
		}		
		try
		{
			
			System.out.print("\n content of the file \n\n");

			String s[]=file.list();
			for(int i=0;i<s.length;i++)
			{
				
				System.out.println(s[i]);
			}
		}
		catch(Exception e)
		{
			System.out.println("\n\n*******"+e.getMessage());
		}
    }
}
